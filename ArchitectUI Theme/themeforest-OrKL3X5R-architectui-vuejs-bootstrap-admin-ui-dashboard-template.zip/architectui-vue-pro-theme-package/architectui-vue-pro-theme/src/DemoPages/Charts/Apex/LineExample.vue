<template>
  <div class="example">
    <apexchart height="350" type="line" :options="chartOptions" :series="series"></apexchart>
    <div class="text-center">
      <button @click="updateChart" class="btn btn-primary">Update!</button>
    </div>
  </div>
</template>

<script>
  import VueApexCharts from 'vue-apexcharts'

  export default {
    name: 'LineExample',
    components: {
      'apexchart': VueApexCharts

    },
    data: function () {
      return {
        chartOptions: {
          xaxis: {
            type: 'datetime',
            categories: ['01/01/2003', '02/01/2003', '03/01/2003', '04/01/2003', '05/01/2003', '06/01/2003', '07/01/2003', '08/01/2003'],
          },
        },
        series: [{
          name: 'Series A',
          data: [30, 40, 45, 50, 49, 60, 70, 91]
        }, {
          name: 'Series B',
          data: [23, 43, 54, 12, 44, 52, 32, 11]
        }]
      }
    },
    methods: {
      generateDayWiseTimeSeries(baseval, count, yrange) {
        var i = 0;
        var series = [];
        while (i < count) {
          var x = baseval;
          var y = Math.floor(Math.random() * (yrange.max - yrange.min + 1)) + yrange.min;

          series.push([x, y]);
          baseval += 86400000;
          i++;
        }
        return series;
      },
      updateChart() {
        let series = [
          {
            name: 'South',
            data: this.generateDayWiseTimeSeries(new Date('11 Feb 2017').getTime(), 20, {
              min: 10,
              max: 60
            })
          },
          {
            name: 'North',
            data: this.generateDayWiseTimeSeries(new Date('11 Feb 2017').getTime(), 20, {
              min: 10,
              max: 20
            })
          },

          {
            name: 'Central',
            data: this.generateDayWiseTimeSeries(new Date('11 Feb 2017').getTime(), 20, {
              min: 10,
              max: 15
            })
          }
        ]

        this.series = series
      }
    }
  }
</script>
