<template>
  <div class="text-xs-center">
    <v-btn fab dark small color="primary">
      <v-icon dark>remove</v-icon>
    </v-btn>

    <v-btn fab dark small color="pink">
      <v-icon dark>favorite</v-icon>
    </v-btn>

    <v-btn fab dark color="indigo">
      <v-icon dark>add</v-icon>
    </v-btn>

    <v-btn fab dark color="teal">
      <v-icon dark>list</v-icon>
    </v-btn>

    <v-btn fab dark large color="cyan">
      <v-icon dark>edit</v-icon>
    </v-btn>

    <v-btn fab dark large color="purple">
      <v-icon dark>android</v-icon>
    </v-btn>
  </div>
</template>
